@props([
    'title' => null,
])

@php
    $themeBase = 'DashboardKit-main';
@endphp

<title>{{ $title ? $title.' - ' : '' }}{{ config('app.name') }}</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="icon" href="{{ asset($themeBase.'/images/favicon.svg') }}" type="image/x-icon">

<link rel="stylesheet" href="{{ asset($themeBase.'/css/feather.css') }}">
<link rel="stylesheet" href="{{ asset($themeBase.'/css/fontawesome.css') }}">
<link rel="stylesheet" href="{{ asset($themeBase.'/css/material.css') }}">
<link rel="stylesheet" href="{{ asset($themeBase.'/css/style.css') }}" id="main-style-link">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css">
<link rel="stylesheet" href="{{ asset($themeBase.'/css/custom.css') }}?v={{ file_exists(public_path($themeBase.'/css/custom.css')) ? filemtime(public_path($themeBase.'/css/custom.css')) : time() }}">

<style>
    /* Hide Mobile Header Bar on Desktop (> 991px) */
    @media only screen and (min-width: 992px) {
        .pc-mob-header,
        .pc-mob-header.pc-header {
            display: none !important;
        }
    }
    :root {
        --brand-primary: {{ $webCustomization['primaryColor'] ?? '#751204' }};
        --brand-primary-rgb: {{ $webCustomization['primaryRgb'] ?? '117, 18, 4' }};
        --brand-primary-dark: {{ $webCustomization['primaryDark'] ?? '#610000' }};
    }

    .btn-primary,
    .btn-check:checked + .btn-primary,
    .btn-check:active + .btn-primary,
    .btn-primary:active,
    .btn-primary.active,
    .show > .btn-primary.dropdown-toggle {
        background-color: var(--brand-primary) !important;
        border-color: var(--brand-primary) !important;
    }

    .btn-primary:hover,
    .btn-primary:focus {
        background-color: var(--brand-primary-dark) !important;
        border-color: var(--brand-primary-dark) !important;
    }

    .btn-primary:focus,
    .btn-check:focus + .btn-primary {
        box-shadow: 0 0 0 0.2rem rgba(var(--brand-primary-rgb), 0.35) !important;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: var(--brand-primary) !important;
        box-shadow: 0 0 0 0.2rem rgba(var(--brand-primary-rgb), 0.25) !important;
    }

    .pc-sidebar,
    .pc-sidebar .m-header,
    .pc-mob-header.pc-header {
        background: var(--brand-primary) !important;
        border-color: var(--brand-primary) !important;
    }

    .pc-sidebar * {
        --bs-primary: var(--brand-primary) !important;
    }
</style>

@stack('styles')
