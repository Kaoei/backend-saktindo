<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('gudang_products', function (Blueprint $table) {
            $table->decimal('price', 15, 2)->default(0)->after('qty');
            $table->decimal('discount', 15, 2)->default(0)->after('price');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('gudang_products', function (Blueprint $table) {
            $table->dropColumn(['price', 'discount']);
        });
    }
};
